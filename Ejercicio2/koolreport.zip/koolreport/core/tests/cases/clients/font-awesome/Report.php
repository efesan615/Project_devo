<?php

class Report extends \koolreport\KoolReport
{
    use \koolreport\clients\FontAwesome;
}